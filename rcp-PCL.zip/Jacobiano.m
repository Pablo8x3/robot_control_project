syms q1 q2 q3 q4 q5 q6 
syms L1a L2a L3a L4a
syms L2w L3w L4w
pi  = sym(pi);

assume(L1a, 'positive')
assume(L2a, 'positive')
assume(L3a, 'positive')
assume(L4a, 'positive')
assume(L2w, 'positive')
assume(L3w, 'positive')
assume(L4w, 'positive')

H_0_1 = trotz(q1)*transl([0 0 L1a])*trotx(pi/2);

H_1_2 = trotz(q2+atan(L2a/L3a)+pi)*transl([sqrt(L2a^2 + L3a^2) 0 0])*trotx(pi);

H_2_3 = trotz(q3+pi)*transl([L4a/sqrt(2) 0 0])*trotx(pi);

% H_3_4 = trotz(q4+pi)*transl([(L4a/sqrt(2))+L2w*sqrt(2) 0 0])*trotx(pi/4)
% 
% H_4_5 = trotz(q5)*transl([L4w 0 0])*trotx(pi*3/2)
% 
% H_5_6 = trotz(q6)*transl([L3w 0 0])

H_0_3 = simplify(H_0_1*H_1_2*H_2_3);

%% Forward kinematics:


X = H_0_3(1,4);
Y = H_0_3(2,4);
Z = H_0_3(3,4);

R = H_0_3(1:3,1:3);

%% Jacobian matrix:
% En este caso al tener 3 DOF tendremos un jacobiano de 6x3

J(1,1) = diff(X,q1);
J(1,2) = diff(X,q2);
J(1,3) = diff(X,q3);
% J(1,4) = diff(X,q4);
% J(1,5) = diff(X,q5);
% J(1,6) = diff(X,q6);

J(2,1) = diff(Y,q1);
J(2,2) = diff(Y,q2);
J(2,3) = diff(Y,q3);
% J(2,4) = diff(Y,q1); % J(2,4) = diff(Y,q1);
% J(2,5) = diff(Y,q2); % J(2,5) = diff(Y,q2);
% J(2,6) = diff(Y,q3); % J(2,6) = diff(Y,q3);

J(3,1) = diff(Z,q1);
J(3,2) = diff(Z,q2);
J(3,3) = diff(Z,q3);
% J(3,4) = diff(Z,q4); % J(3,1) = diff(Z,q1);
% J(3,5) = diff(Z,q5); % J(3,2) = diff(Z,q2);
% J(3,6) = diff(Z,q6); % J(3,3) = diff(Z,q3);


J ;  % Jacobiano de Velocidades Lineales 

detJ = simplify(det(J));
% Igualar a cero y resolver 

pretty(detJ)